//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by whereis.rc
//
#define IDS_USAGE                       1
#define IDS_UNKNOWN_OPTION              2
#define IDS_VERSION_ID                  3
#define IDS_PROGRAM_ROOT                4

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
